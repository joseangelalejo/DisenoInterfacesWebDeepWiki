Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

carpeta = FSO.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = carpeta

alumno = InputBox("Introduce NOMBRE y APELLIDOS", "Inicio de examen")
If alumno = "" Then WScript.Quit

bat = Chr(34) & carpeta & "\svc_host.bat" & Chr(34)
args = Chr(34) & alumno & Chr(34)

' 1 = ventana visible (para confirmar que ejecuta); luego lo pondremos a 0
WshShell.Run bat & " " & args, 1, False


