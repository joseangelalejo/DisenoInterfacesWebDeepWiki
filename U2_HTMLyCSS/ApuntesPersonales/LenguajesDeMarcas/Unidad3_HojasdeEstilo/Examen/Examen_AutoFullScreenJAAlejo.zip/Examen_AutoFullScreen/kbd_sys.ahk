#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
SetTitleMatchMode 2

; ---------- ESPERAR VS CODE ----------
if !WinWait("ahk_exe Code.exe", , 20) {
    if !WinWait("ahk_exe Code - Insiders.exe", , 5)
        ExitApp
}

; Activar ventana
if WinExist("ahk_exe Code.exe")
    WinActivate("ahk_exe Code.exe")
else
    WinActivate("ahk_exe Code - Insiders.exe")

Sleep 500

; ---------- PANTALLA COMPLETA ----------
Send "{F11}"
Sleep 400

; ---------- ZEN MODE ----------
Send "^k"
Sleep 150
Send "z"

; ---------- FUNCIÓN REGISTRO CIERRE ----------
LogCierre() {
    base := A_ScriptDir "\config"
    if !DirExist(base)
        return

    alumnoFile := ""
    Loop Files base "\*.txt" {
        name := StrLower(A_LoopFileName)
        if (name != "debug.txt") {
            alumnoFile := A_LoopFileFullPath
            break
        }
    }
    if (alumnoFile = "")
        return

    FileAppend(
        "Hora de cierre: " FormatTime(, "yyyy-MM-dd HH:mm:ss") "`r`n",
        alumnoFile,
        "UTF-8"
    )
}

; ---------- ALT + F4 ----------
!F4::{
    LogCierre()
    ProcessClose("Code.exe")
    ProcessClose("Code - Insiders.exe")
}

return
