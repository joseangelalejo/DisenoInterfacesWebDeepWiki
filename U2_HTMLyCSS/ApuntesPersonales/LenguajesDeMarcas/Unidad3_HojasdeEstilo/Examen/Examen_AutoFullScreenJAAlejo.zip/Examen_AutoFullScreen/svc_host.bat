@echo off
setlocal EnableExtensions
cd /d "%~dp0"

REM Nombre del alumno (puede venir con espacios)
set "alumno=%~1"
if "%alumno%"=="" set "alumno=DESCONOCIDO"

REM Log para depurar
if not exist "config" mkdir "config"
> "config\debug.txt" (
  echo === DEBUG ===
  echo Carpeta: %CD%
  echo Alumno: %alumno%
  echo Fecha: %date% %time%
)

REM Guardar alumno
REM Nombre del alumno
set "alumno=%~1"
if "%alumno%"=="" set "alumno=DESCONOCIDO"

REM Normalizar nombre para archivo
set "alumno_file=%alumno: =_%"

REM Crear config si no existe
if not exist "config" mkdir "config"

REM Guardar archivo con nombre del alumno
(
  echo Alumno: %alumno%
  echo Fecha: %date% %time%
) > "config\%alumno_file%.txt"



attrib +h "config\alumno.txt" >nul 2>nul

REM Workspace
set "WS=%CD%\config\Examen.code-workspace"
echo Workspace: "%WS%" >> "config\debug.txt"

if not exist "%WS%" (
  echo ERROR: No existe el workspace >> "config\debug.txt"
  exit /b 1
)

REM Buscar Code.exe (rutas típicas)
set "VSC=%LocalAppData%\Programs\Microsoft VS Code\Code.exe"
if not exist "%VSC%" set "VSC=%ProgramFiles%\Microsoft VS Code\Code.exe"
if not exist "%VSC%" set "VSC=%ProgramFiles(x86)%\Microsoft VS Code\Code.exe"

echo VSCodeExe: "%VSC%" >> "config\debug.txt"

if not exist "%VSC%" (
  echo ERROR: No se encontro Code.exe >> "config\debug.txt"
  exit /b 1
)

REM Abrir VS Code
start "" "%VSC%" --new-window "%WS%"
echo OK: Lanzado VS Code >> "config\debug.txt"

REM AutoHotkey (si está)
start "" "%~dp0AutoHotkey64.exe" "%~dp0kbd_sys.ahk"

timeout /t 5 >nul
if exist "%~dp0AutoHotkey64.exe" (
  rem start "" "%~dp0AutoHotkey64.exe" "%~dp0iniciar_examen.ahk"
  echo OK: Lanzado AutoHotkey >> "config\debug.txt"
) else (
  echo AVISO: Falta AutoHotkey64.exe >> "config\debug.txt"
)

exit /b 0

